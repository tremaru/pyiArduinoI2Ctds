void setup(void);
void loop(void);
int main()
{
	setup();
	for (;;)
		loop();
}
